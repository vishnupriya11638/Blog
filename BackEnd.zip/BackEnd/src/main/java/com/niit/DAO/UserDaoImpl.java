package com.niit.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.niit.Model.User;
@Component
public class UserDaoImpl implements UserDao{

	private static List<User> user;
	{
		user = new ArrayList();
		user.add(new User(101, "John Doe",1, "djohn@gmail.com", 121-232-3435));
		user.add(new User(101, "John Doe",1, "djohn@gmail.com", 121-232-3435));
		user.add(new User(101, "John Doe",1, "djohn@gmail.com", 121-232-3435));
		user.add(new User(101, "John Doe",1, "djohn@gmail.com", 121-232-3435));
		
	}
	public List list() {
		// TODO Auto-generated method stub
		return user;
	}

	

	public User create(User users) {
		// TODO Auto-generated method stub
		users.setUser_id(System.currentTimeMillis());
		user.add(users);
		
		return users;
	}

	public Long delete(Long id) {
		// TODO Auto-generated method stub
		for (User c : user) {
			if (c.getUser_id()==id) {
				user.remove(c);
				return id;
			}
		}

		return null;
	}

	public User update(Long id, User users) {
		// TODO Auto-generated method stub
		for (User c : user) {
			if (c.getUser_id()==id) {
				users.setUser_id(c.getUser_id());
				user.remove(c);
				user.add(users);
				return users;
			}
		}

		return null;
	}

	public User get(Long id) {
		// TODO Auto-generated method stub
		for (User c : user) {
			if (c.getUser_id()==id) {
				return c;
			}
		}
		return null;
	}

	

}
